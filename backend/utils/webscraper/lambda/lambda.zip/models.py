from typing import List, Optional
from datetime import datetime

class ScrapedEvent():
    title: str
    start_date: Optional[str]
    end_date: Optional[str]
    time: Optional[str] = None
    location: Optional[str]
    postal_code: Optional[str]
    category: Optional[float]
    price: Optional[float]
    description: str
    image_urls: List[str]
    organizer: Optional[str]
    official_link: Optional[str]
    url: List[str]
    
class DBEvent():
    title: str
    start_date: Optional[datetime]
    end_date: Optional[datetime]
    address: Optional[str]
    price: Optional[float]
    categories: Optional[List[float]]
    description: Optional[str]
    images: Optional[List[str]]
    lat: Optional[float]
    long: Optional[float]

